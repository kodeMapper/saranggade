module.exports = [
"[project]/.next-internal/server/app/admin/review/[id]/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_admin_review_%5Bid%5D_page_actions_c46f1813.js.map