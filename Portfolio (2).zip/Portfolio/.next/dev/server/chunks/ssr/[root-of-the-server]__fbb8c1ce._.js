module.exports = [
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[project]/src/data/resume.json (json)", ((__turbopack_context__) => {

__turbopack_context__.v(JSON.parse("{\"personalInfo\":{\"name\":\"Sarang Gade\",\"role\":\"Full-Stack Developer\",\"location\":\"Nagpur, Maharashtra - 440013\",\"email\":\"saranganilgade@gmail.com\",\"phone\":\"7720059749\",\"linkedin\":\"https://www.linkedin.com/in/sarang-gade\",\"github\":\"https://github.com/kodeMapper\",\"twitter\":\"https://twitter.com/thesaranggade\",\"leetcode\":\"https://leetcode.com/u/Kodemapper/\",\"image\":\"/images/profile.jpg\"},\"education\":[{\"institution\":\"Shri. Ramdeobaba College of Engineering and Management\",\"degree\":\"Bachelor of Technology in Electronics and Computer Science\",\"duration\":\"Aug. 2023 – Present\",\"location\":\"Nagpur, Maharashtra\",\"grade\":\"CGPA: 9.44/10\"},{\"institution\":\"Shri. Ramdeobaba College of Engineering and Management\",\"degree\":\"Minor in Information Technology\",\"duration\":\"Aug. 2024 – Present\",\"location\":\"Nagpur, Maharashtra\",\"grade\":\"Grade: AA\"}],\"experience\":[{\"title\":\"Full-stack Developer Intern\",\"company\":\"AARA Green Infosolutions Pvt. Ltd.\",\"duration\":\"April 2025 – August 2025\",\"location\":\"Nagpur, Maharashtra\",\"image\":\"/images/experience/aara-green.png\",\"highlights\":[\"<span>Completed a 3-month paid internship, building the official <a href='https://merididi.com/' target='_blank' rel='noopener noreferrer' style='color: var(--primary); text-decoration: none;'>'Meri Didi' website ↗</a> and admin panel using React/Supabase, boosting digital presence.</span>\"]},{\"title\":\"Software Lead\",\"company\":\"Embedded Club, RCOEM\",\"duration\":\"Sep 2025 – Present\",\"location\":\"Nagpur, Maharashtra\",\"image\":\"/images/experience/embedded-club.jpg\",\"highlights\":[\"Conducted technical workshops and guided juniors in the software field.\",\"Mentored multiple project and hackathon teams, fostering innovation.\"]},{\"title\":\"Development Hackathons\",\"company\":\"Frontend/Backend Developer\",\"duration\":\"Sep 2024 – Present\",\"location\":\"Maharashtra\",\"image\":\"/images/experience/hackathons.png\",\"highlights\":[\"Secured top 10 ranks in 5+ hackathons and won multiple events.\",\"Led teams to success as a Team Leader in high-pressure environments.\"]}],\"projects\":[{\"name\":\"PulseAI – Health Risk Prediction\",\"tech\":\"Python, Flask, React, MongoDB\",\"date\":\"Nov 2025\",\"github\":\"https://github.com/kodeMapper/pulseai-iot-ml-project\",\"demo\":\"https://pulseai-frontend.vercel.app/\",\"image\":\"/images/projects/pulseai/landing.png\",\"points\":[\"ML system for maternal health risk prediction (86.7% accuracy).\",\"End-to-end pipeline: model training, Flask API, React dashboard.\",\"Deployed on Vercel and Render.\"],\"caseStudy\":{\"summary\":\"PulseAI is a full-stack machine learning application that helps healthcare providers identify pregnant women at risk. By analyzing 6 simple vital signs, our system can predict whether a patient is at Low, Medium, or High risk with 86.7% accuracy. It prioritizes recall to minimize false negatives in critical medical scenarios.\",\"features\":[\"Real-time Risk Assessment (86.7% Accuracy)\",\"Dark Neon Dashboard with Glassmorphism\",\"SMOTE Class Balancing for 94.5% Recall\",\"Flask API & MongoDB Integration\",\"Interactive Patient Directory & History\"],\"stackReasoning\":[{\"tool\":\"Gradient Boosting\",\"reason\":\"Chosen for higher accuracy (86.7%) and recall over Random Forest/XGBoost.\"},{\"tool\":\"Flask 2.3\",\"reason\":\"Lightweight REST API to serve real-time predictions.\"},{\"tool\":\"React 19\",\"reason\":\"Modern UI for doctors with Framer Motion animations.\"},{\"tool\":\"SMOTE\",\"reason\":\"Synthetic minority oversampling to fix severe class imbalance.\"},{\"tool\":\"MongoDB\",\"reason\":\"Flexible storage for patient records and reading history.\"}],\"challenges\":[\"Minimizing false negatives: 'Missing a high-risk case is worse than a false alarm'.\",\"Handling class imbalance where high-risk cases were originally rare.\",\"Optimizing model recall from 60% to 94.5% using SMOTE.\"],\"gallery\":[\"/images/projects/pulseai/landing.png\",\"/images/projects/pulseai/dashboard.png\",\"/images/projects/pulseai/analytics.png\",\"/images/projects/pulseai/report.png\"]}},{\"name\":\"Personal Portfolio Website\",\"tech\":\"Next.js 14, Framer Motion, CSS Modules\",\"date\":\"Dec 2024\",\"github\":\"https://github.com/kodeMapper/saranggade\",\"demo\":\"https://saranggade.vercel.app/\",\"image\":\"/images/projects/portfolio/landing.png\",\"points\":[\"Interactive 3D portfolio featuring immersive scroll-snap.\",\"Custom glassmorphism design with theme switching.\",\"Performance optimized with Next.js App Router.\"],\"caseStudy\":{\"summary\":\"A modern, high-performance portfolio website built to showcase my journey as a developer. It features a seamless scroll-snap experience, complex 3D animations using Framer Motion, and a fully custom glassmorphism design system that adapts to both light and dark modes.\",\"features\":[\"Scroll-Snap Layout with 3D Transitions\",\"Dynamic Project Case Studies\",\"Codolio Card 3D Integration\",\"Light/Dark Mode with CSS Variables\",\"Responsive Masonry Grids\"],\"stackReasoning\":[{\"tool\":\"Next.js 14\",\"reason\":\"Server components for fast initial load and SEO.\"},{\"tool\":\"Framer Motion\",\"reason\":\"Complex orchestrations for scroll/hover animations.\"},{\"tool\":\"CSS Modules\",\"reason\":\"Scoped styling to prevent conflicts in component architecture.\"},{\"tool\":\"Lucide React\",\"reason\":\"Lightweight, consistent icon set for UI elements.\"}],\"challenges\":[\"Implementing smooth scroll-snap behavior across different browsers.\",\"Optimizing heavy image assets for rapid LCP (Largest Contentful Paint).\",\"Designing a cohesive theme system without relying on heavy UI libraries.\"],\"gallery\":[\"/images/projects/portfolio/landing.png\",\"/images/projects/portfolio/featured_projects.png\",\"/images/projects/portfolio/projects.png\",\"/images/projects/portfolio/experience.png\",\"/images/projects/portfolio/contact.png\"]}},{\"name\":\"Stampede Management System\",\"tech\":\"Python, YOLOv8, Flask, React\",\"date\":\"Oct 2025\",\"github\":\"https://github.com/kodeMapper/stamped-management\",\"demo\":\"https://stamped-management.onrender.com\",\"image\":\"/images/projects/stampede/overview.png\",\"points\":[\"Real-time crowd analysis & weapon detection using YOLOv8.\",\"Tri-modal analytics: Crowd density, Lost Person Search, Weapon alerts.\",\"Sub-100ms alert latency with 90%+ model accuracy.\"],\"caseStudy\":{\"summary\":\"An Integrated Smart Surveillance Platform enabling real-time stampede prevention through synchronized crowd analytics, facial recognition for lost-person search, and weapon detection. It processes multiple camera feeds parallelly to trigger evacuations before safety thresholds are breached.\",\"features\":[\"Tri-modal Analytics: Crowd, Face, & Weapon Detection\",\"One-Click Lost Person Search (Haar/ORB)\",\"Sub-100ms Alert Latency\",\"Parallel Processing (Thread-safe Camera Manager)\",\"Responsive Dashboard with Live Telemetry\"],\"stackReasoning\":[{\"tool\":\"YOLOv8\",\"reason\":\"Standard for high-speed object detection (guns/crowd) with 91% precision.\"},{\"tool\":\"Haar/ORB\",\"reason\":\"Efficient facial recognition pipeline for lost-person identification.\"},{\"tool\":\"Flask\",\"reason\":\"Serves MJPEG streams and REST API for telemetry.\"},{\"tool\":\"Next.js\",\"reason\":\"Lazy-loads video feeds to optimize browser bandwidth.\"},{\"tool\":\"Python Threading\",\"reason\":\"Ensures capture threads run non-blocking for <45ms latency.\"}],\"challenges\":[\"Synchronizing 3 heavy detection models (Crowd, Face, Weapon) on a single feed.\",\"Achieving <100ms latency on commodity hardware (Windows laptops).\",\"Managing browser connection limits with multiple MJPEG streams.\"],\"gallery\":[\"/images/projects/stampede/overview.png\",\"/images/projects/stampede/face_rec.png\",\"/images/projects/stampede/weapon_det.png\",\"/images/projects/stampede/settings.png\"]}},{\"name\":\"SmartVision - GPS & Fall Detection\",\"tech\":\"Node.js, React, Socket.io, Google Maps, ESP32\",\"date\":\"April 2025\",\"github\":\"https://github.com/kodeMapper/shivCodeSena_HTH_2k25\",\"demo\":\"https://gps-monitoring-seven.vercel.app/\",\"image\":\"/images/projects/gps/map.png\",\"points\":[\"IoT wearable for elderly fall detection & real-time tracking.\",\"Integrated MPU6050 sensors with ML-based fall algorithms.\",\"Live dashboard with geofencing and SOS alerts.\"],\"caseStudy\":{\"summary\":\"SmartVision is an enhanced IoT-based fall detection and family safety tracking system. It combines ESP32 hardware with advanced sensor fusion (accelerometer + gyroscope) to detect falls with precision, automatically triggering alerts to caregivers via SMS and a real-time web dashboard.\",\"features\":[\"Advanced Fall Detection (MPU6050 + ML)\",\"Real-time GPS Tracking & Geofencing\",\"Obstacle Detection via LiDAR\",\"Automated SMS/Email Emergency Alerts\",\"Caregiver Dashboard with Health Analytics\"],\"stackReasoning\":[{\"tool\":\"ESP32\",\"reason\":\"Dual-core processor capable of handling sensor fusion and WiFi simultaneously.\"},{\"tool\":\"Node.js\",\"reason\":\"Scalable backend to manage parallel WebSocket connections from devices.\"},{\"tool\":\"Twilio\",\"reason\":\"Reliable, programmable SMS gateway for critical emergency alerts.\"},{\"tool\":\"React\",\"reason\":\"Dynamic dashboard for real-time map updates and status monitoring.\"},{\"tool\":\"MPU6050\",\"reason\":\"6-axis precision IMU essential for accurate fall pattern recognition.\"}],\"challenges\":[\"Distinguishing actual falls from daily activities to reduce false positives.\",\"Optimizing battery life while maintaining continuous GPS/Sensor polling.\",\"Ensuring instant alert delivery even in areas with fluctuating network.\"],\"gallery\":[\"/images/projects/gps/map.png\",\"/images/projects/gps/zones.png\",\"/images/projects/gps/devices.png\",\"/images/projects/gps/zones_empty.png\"]}},{\"name\":\"Ben 10 Universe\",\"tech\":\"HTML5, CSS3, JavaScript\",\"date\":\"July 2024\",\"github\":\"https://github.com/kodeMapper/Ben-10-Universe\",\"demo\":\"https://ben-10-universe.vercel.app/\",\"image\":\"/images/projects/ben10/landing.png\",\"points\":[\"My first project: A tribute built entirely with Vanilla JS & CSS.\",\"Immersive audio-visual experience with transformation effects.\"],\"caseStudy\":{\"summary\":\"Ben 10 Universe is a special project as it was my very first website built from scratch using only HTML, CSS, and JavaScript. It serves as an interactive tribute to the show, featuring character bios, alien transformations, and nostalgic sound effects, demonstrating the power of vanilla web technologies without frameworks.\",\"features\":[\"Custom CSS Animations (Keyframes)\",\"DOM Manipulation for Alien Switching\",\"Audio Integration (Omnitrix SFX)\",\"Responsive Flexbox Layouts\",\"Interactive Storytelling Elements\"],\"stackReasoning\":[{\"tool\":\"Vanilla CSS\",\"reason\":\"To master the fundamentals of styling and animation.\"},{\"tool\":\"JavaScript\",\"reason\":\"Handling logic for the interactive 'Omnitrix' dial.\"},{\"tool\":\"HTML5\",\"reason\":\"Semantic structure for better accessibility and SEO.\"}],\"challenges\":[\"Implementing complex animations without animation libraries (Framer Motion/GSAP).\",\"Managing state (selected alien) using only vanilla JavaScript variables.\",\"Ensuring cross-browser compatibility for audio autoplay policies.\"],\"gallery\":[\"/images/projects/ben10/landing.png\",\"/images/projects/ben10/story.png\",\"/images/projects/ben10/alien_x.png\",\"/images/projects/ben10/hero_time.png\",\"/images/projects/ben10/footer.png\"]}}],\"skills\":{\"languages\":[\"JavaScript\",\"Node\",\"Express\",\"HTML\",\"CSS\",\"Bootstrap\",\"Python\",\"Java\",\"C\",\"PHP\",\"MySQL\"],\"tools\":[\"VS Code\",\"Eclipse\",\"Intellij\",\"MIT App Inventor\",\"Postman\",\"MongoDB\",\"Business Intelligence\",\"Business Intelligence Tools\",\"Supabase\",\"StarUML\",\"Data Modeling\",\"Raspberry Pi\",\"IoT\",\"API\",\"Project Management\",\"C Programming\",\"Python\",\"Data Warehousing\",\"Software Development\"],\"frameworks\":[\"Vercel\",\"Git\",\"GitHub\",\"MS Power BI\",\"Tableau\",\"Star UML\",\"Render\"]}}"));}),
"[project]/src/data/resume.js [app-ssr] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$resume$2e$json__$28$json$29$__ = __turbopack_context__.i("[project]/src/data/resume.json (json)");
;
;
}),
"[project]/src/data/resume.json (json) <export default as resumeData>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "resumeData",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$resume$2e$json__$28$json$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$resume$2e$json__$28$json$29$__ = __turbopack_context__.i("[project]/src/data/resume.json (json)");
}),
"[externals]/next/dist/server/app-render/action-async-storage.external.js [external] (next/dist/server/app-render/action-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/action-async-storage.external.js", () => require("next/dist/server/app-render/action-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[project]/src/app/project/[id]/project.module.css [app-ssr] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "actionTitle": "project-module__KCYNdq__actionTitle",
  "actionsCard": "project-module__KCYNdq__actionsCard",
  "backLink": "project-module__KCYNdq__backLink",
  "card": "project-module__KCYNdq__card",
  "container": "project-module__KCYNdq__container",
  "contentCard": "project-module__KCYNdq__contentCard",
  "contentRow": "project-module__KCYNdq__contentRow",
  "featureIndex": "project-module__KCYNdq__featureIndex",
  "featureItem": "project-module__KCYNdq__featureItem",
  "featureList": "project-module__KCYNdq__featureList",
  "featureText": "project-module__KCYNdq__featureText",
  "galleryBtn": "project-module__KCYNdq__galleryBtn",
  "galleryControls": "project-module__KCYNdq__galleryControls",
  "galleryImage": "project-module__KCYNdq__galleryImage",
  "galleryImageContainer": "project-module__KCYNdq__galleryImageContainer",
  "gallerySection": "project-module__KCYNdq__gallerySection",
  "galleryTrack": "project-module__KCYNdq__galleryTrack",
  "gridContainer": "project-module__KCYNdq__gridContainer",
  "heroCard": "project-module__KCYNdq__heroCard",
  "highlightItem": "project-module__KCYNdq__highlightItem",
  "highlightNumber": "project-module__KCYNdq__highlightNumber",
  "highlightText": "project-module__KCYNdq__highlightText",
  "highlightsGrid": "project-module__KCYNdq__highlightsGrid",
  "label": "project-module__KCYNdq__label",
  "navBar": "project-module__KCYNdq__navBar",
  "navItem": "project-module__KCYNdq__navItem",
  "navLinks": "project-module__KCYNdq__navLinks",
  "sectionHeading": "project-module__KCYNdq__sectionHeading",
  "sidebar": "project-module__KCYNdq__sidebar",
  "stackGrid": "project-module__KCYNdq__stackGrid",
  "stackHeader": "project-module__KCYNdq__stackHeader",
  "stackItem": "project-module__KCYNdq__stackItem",
  "stackName": "project-module__KCYNdq__stackName",
  "stackReason": "project-module__KCYNdq__stackReason",
  "statBox": "project-module__KCYNdq__statBox",
  "statLabel": "project-module__KCYNdq__statLabel",
  "statValue": "project-module__KCYNdq__statValue",
  "statsGrid": "project-module__KCYNdq__statsGrid",
  "summary": "project-module__KCYNdq__summary",
  "techIcon": "project-module__KCYNdq__techIcon",
  "techList": "project-module__KCYNdq__techList",
  "title": "project-module__KCYNdq__title",
});
}),
"[project]/src/components/ThemeToggle.module.css [app-ssr] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "toggle": "ThemeToggle-module__sGqMhG__toggle",
});
}),
"[project]/src/components/ThemeToggle.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$sun$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Sun$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/sun.js [app-ssr] (ecmascript) <export default as Sun>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$moon$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Moon$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/moon.js [app-ssr] (ecmascript) <export default as Moon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ThemeToggle$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/src/components/ThemeToggle.module.css [app-ssr] (css module)");
"use client";
;
;
;
;
const ThemeToggle = ()=>{
    const [theme, setTheme] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])('dark');
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        // Default to dark
        document.documentElement.setAttribute('data-theme', 'dark');
        setTheme('dark');
    }, []);
    const toggleTheme = ()=>{
        const newTheme = theme === 'dark' ? 'light' : 'dark';
        setTheme(newTheme);
        document.documentElement.setAttribute('data-theme', newTheme);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ThemeToggle$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].toggle,
        onClick: toggleTheme,
        "aria-label": "Toggle Theme",
        children: theme === 'dark' ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$sun$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Sun$3e$__["Sun"], {
            size: 20
        }, void 0, false, {
            fileName: "[project]/src/components/ThemeToggle.jsx",
            lineNumber: 23,
            columnNumber: 27
        }, ("TURBOPACK compile-time value", void 0)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$moon$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Moon$3e$__["Moon"], {
            size: 20
        }, void 0, false, {
            fileName: "[project]/src/components/ThemeToggle.jsx",
            lineNumber: 23,
            columnNumber: 47
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/src/components/ThemeToggle.jsx",
        lineNumber: 22,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
const __TURBOPACK__default__export__ = ThemeToggle;
}),
"[project]/src/utils/techIcons.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getTechIcon",
    ()=>getTechIcon,
    "techMap",
    ()=>techMap
]);
const techMap = {
    "Python": "python",
    "Flask": "flask",
    "React": "react",
    "MongoDB": "mongodb",
    "Next.js 14": "nextdotjs",
    "Next.js": "nextdotjs",
    "Framer Motion": "framer",
    "CSS Modules": "cssmodules",
    "YOLOv8": "ultralytics",
    "Node.js": "nodedotjs",
    "Socket.io": "socketdotio",
    "Google Maps": "googlemaps",
    "ESP32": "espressif",
    "HTML5": "html5",
    "CSS3": "css3",
    "JavaScript": "javascript"
};
const getTechIcon = (techName)=>{
    const raw = techName.trim();
    // Check direct map
    if (techMap[raw]) {
        return `/images/tech/${techMap[raw]}.svg`;
    }
    // Check cleaned keys (case insensitive)
    const lower = raw.toLowerCase();
    for(const key in techMap){
        if (key.toLowerCase() === lower) {
            return `/images/tech/${techMap[key]}.svg`;
        }
    }
    // Fallback: Use simple icons CDN which has almost everything
    // This satisfies "automatically map the svg for mentioned techstack"
    const slug = lower.replace(/[\s\.]/g, ''); // "node.js" -> "nodejs"
    return `https://cdn.simpleicons.org/${slug}`;
};
}),
"[externals]/tty [external] (tty, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("tty", () => require("tty"));

module.exports = mod;
}),
"[externals]/util [external] (util, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("util", () => require("util"));

module.exports = mod;
}),
"[externals]/os [external] (os, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("os", () => require("os"));

module.exports = mod;
}),
"[externals]/node:path [external] (node:path, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:path", () => require("node:path"));

module.exports = mod;
}),
"[externals]/node:path [external] (node:path, cjs) <export default as minpath>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "minpath",
    ()=>__TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:path [external] (node:path, cjs)");
}),
"[externals]/node:process [external] (node:process, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:process", () => require("node:process"));

module.exports = mod;
}),
"[externals]/node:process [external] (node:process, cjs) <export default as minproc>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "minproc",
    ()=>__TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$process__$5b$external$5d$__$28$node$3a$process$2c$__cjs$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$process__$5b$external$5d$__$28$node$3a$process$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:process [external] (node:process, cjs)");
}),
"[externals]/node:url [external] (node:url, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:url", () => require("node:url"));

module.exports = mod;
}),
"[externals]/node:url [external] (node:url, cjs) <export fileURLToPath as urlToPath>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "urlToPath",
    ()=>__TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$url__$5b$external$5d$__$28$node$3a$url$2c$__cjs$29$__["fileURLToPath"]
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$url__$5b$external$5d$__$28$node$3a$url$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:url [external] (node:url, cjs)");
}),
"[project]/src/app/project/[id]/page.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ProjectDetail
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$resume$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/data/resume.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$resume$2e$json__$28$json$29$__$3c$export__default__as__resumeData$3e$__ = __turbopack_context__.i("[project]/src/data/resume.json (json) <export default as resumeData>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/src/app/project/[id]/project.module.css [app-ssr] (css module)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$left$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronLeft$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/chevron-left.js [app-ssr] (ecmascript) <export default as ChevronLeft>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$right$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronRight$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/chevron-right.js [app-ssr] (ecmascript) <export default as ChevronRight>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/components/AnimatePresence/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ThemeToggle$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ThemeToggle.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$techIcons$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/techIcons.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$markdown$2f$lib$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__Markdown__as__default$3e$__ = __turbopack_context__.i("[project]/node_modules/react-markdown/lib/index.js [app-ssr] (ecmascript) <export Markdown as default>");
"use client";
;
;
;
;
;
;
;
;
;
;
;
function ProjectDetail({ params }) {
    // Unwrap params using React.use() for Next.js 15+ support
    const unwrappedParams = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].use(params);
    const id = parseInt(unwrappedParams.id);
    if (isNaN(id) || id < 0 || id >= __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$resume$2e$json__$28$json$29$__$3c$export__default__as__resumeData$3e$__["resumeData"].projects.length) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["notFound"])();
    }
    const project = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$resume$2e$json__$28$json$29$__$3c$export__default__as__resumeData$3e$__["resumeData"].projects[id];
    const { caseStudy } = project;
    // If no case study data, fallback or show basics? 
    // We added mock data for all, so it should be fine.
    // Gallery State
    const [currentImageIndex, setCurrentImageIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(0);
    const gallery = caseStudy?.gallery || [
        project.image
    ]; // Fallback to main image
    const nextImage = ()=>{
        setCurrentImageIndex((prev)=>(prev + 1) % gallery.length);
    };
    const prevImage = ()=>{
        setCurrentImageIndex((prev)=>(prev - 1 + gallery.length) % gallery.length);
    };
    // Auto-slide
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const timer = setInterval(nextImage, 4000); // 4 seconds
        return ()=>clearInterval(timer);
    }, [
        gallery.length
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].container,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].navBar,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                        href: "/",
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].backLink,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$left$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronLeft$3e$__["ChevronLeft"], {
                                size: 16
                            }, void 0, false, {
                                fileName: "[project]/src/app/project/[id]/page.js",
                                lineNumber: 53,
                                columnNumber: 21
                            }, this),
                            " Back to home"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/project/[id]/page.js",
                        lineNumber: 52,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].navLinks,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                href: project.github,
                                target: "_blank",
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].navItem,
                                children: "Github"
                            }, void 0, false, {
                                fileName: "[project]/src/app/project/[id]/page.js",
                                lineNumber: 56,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                href: project.demo,
                                target: "_blank",
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].navItem,
                                children: "Live"
                            }, void 0, false, {
                                fileName: "[project]/src/app/project/[id]/page.js",
                                lineNumber: 57,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ThemeToggle$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                fileName: "[project]/src/app/project/[id]/page.js",
                                lineNumber: 58,
                                columnNumber: 21
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/project/[id]/page.js",
                        lineNumber: 55,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/project/[id]/page.js",
                lineNumber: 51,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].gridContainer,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].card} ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].heroCard}`,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].label,
                                children: "CASE STUDY"
                            }, void 0, false, {
                                fileName: "[project]/src/app/project/[id]/page.js",
                                lineNumber: 66,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].title,
                                children: project.name
                            }, void 0, false, {
                                fileName: "[project]/src/app/project/[id]/page.js",
                                lineNumber: 67,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].summary,
                                style: {
                                    color: '#ccc',
                                    fontSize: '0.95rem',
                                    lineHeight: '1.6'
                                },
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$markdown$2f$lib$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__Markdown__as__default$3e$__["default"], {
                                    children: caseStudy?.summary || project.points.join(' ')
                                }, void 0, false, {
                                    fileName: "[project]/src/app/project/[id]/page.js",
                                    lineNumber: 69,
                                    columnNumber: 25
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/app/project/[id]/page.js",
                                lineNumber: 68,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].highlightsGrid,
                                children: caseStudy?.features?.slice(0, 3).map((feature, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].highlightItem,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].highlightNumber,
                                                children: [
                                                    "Feature ",
                                                    i + 1
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/project/[id]/page.js",
                                                lineNumber: 75,
                                                columnNumber: 33
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].highlightText,
                                                children: feature
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/project/[id]/page.js",
                                                lineNumber: 76,
                                                columnNumber: 33
                                            }, this)
                                        ]
                                    }, i, true, {
                                        fileName: "[project]/src/app/project/[id]/page.js",
                                        lineNumber: 74,
                                        columnNumber: 29
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/src/app/project/[id]/page.js",
                                lineNumber: 72,
                                columnNumber: 21
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/project/[id]/page.js",
                        lineNumber: 65,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].sidebar,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].actionsCard,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].actionTitle,
                                    children: "PROJECT LINKS"
                                }, void 0, false, {
                                    fileName: "[project]/src/app/project/[id]/page.js",
                                    lineNumber: 85,
                                    columnNumber: 25
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].statsGrid,
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].statBox,
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].statLabel,
                                                    children: "KEY FEATURES"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/project/[id]/page.js",
                                                    lineNumber: 89,
                                                    columnNumber: 33
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].statValue,
                                                    children: caseStudy?.features?.length || 0
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/project/[id]/page.js",
                                                    lineNumber: 90,
                                                    columnNumber: 33
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/project/[id]/page.js",
                                            lineNumber: 88,
                                            columnNumber: 29
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].statBox,
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].statLabel,
                                                    children: "TECH USED"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/project/[id]/page.js",
                                                    lineNumber: 93,
                                                    columnNumber: 33
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].statValue,
                                                    children: project.tech.split(',').length
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/project/[id]/page.js",
                                                    lineNumber: 94,
                                                    columnNumber: 33
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/project/[id]/page.js",
                                            lineNumber: 92,
                                            columnNumber: 29
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/project/[id]/page.js",
                                    lineNumber: 87,
                                    columnNumber: 25
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].techList,
                                    children: project.tech.split(',').slice(0, 5).map((t, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].techIcon,
                                            title: t.trim(),
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                                src: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$techIcons$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getTechIcon"])(t),
                                                onError: (e)=>{
                                                    e.target.style.display = 'none';
                                                },
                                                alt: t.trim()
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/project/[id]/page.js",
                                                lineNumber: 101,
                                                columnNumber: 37
                                            }, this)
                                        }, i, false, {
                                            fileName: "[project]/src/app/project/[id]/page.js",
                                            lineNumber: 100,
                                            columnNumber: 33
                                        }, this))
                                }, void 0, false, {
                                    fileName: "[project]/src/app/project/[id]/page.js",
                                    lineNumber: 98,
                                    columnNumber: 25
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/project/[id]/page.js",
                            lineNumber: 84,
                            columnNumber: 21
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/app/project/[id]/page.js",
                        lineNumber: 83,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/project/[id]/page.js",
                lineNumber: 63,
                columnNumber: 13
            }, this),
            gallery && gallery.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].gallerySection,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].galleryTrack,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AnimatePresence"], {
                            mode: "wait",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["motion"].div, {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].galleryImageContainer,
                                initial: {
                                    opacity: 0,
                                    x: 100
                                },
                                animate: {
                                    opacity: 1,
                                    x: 0
                                },
                                exit: {
                                    opacity: 0,
                                    x: -100
                                },
                                transition: {
                                    duration: 0.5
                                },
                                children: gallery[currentImageIndex] && gallery[currentImageIndex].startsWith('linear') ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    style: {
                                        width: '100%',
                                        height: '100%',
                                        background: gallery[currentImageIndex]
                                    }
                                }, void 0, false, {
                                    fileName: "[project]/src/app/project/[id]/page.js",
                                    lineNumber: 128,
                                    columnNumber: 37
                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                    src: gallery[currentImageIndex] || '/images/projects/placeholder.png',
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].galleryImage,
                                    alt: "UI Screenshot"
                                }, void 0, false, {
                                    fileName: "[project]/src/app/project/[id]/page.js",
                                    lineNumber: 130,
                                    columnNumber: 37
                                }, this)
                            }, currentImageIndex, false, {
                                fileName: "[project]/src/app/project/[id]/page.js",
                                lineNumber: 118,
                                columnNumber: 29
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/app/project/[id]/page.js",
                            lineNumber: 117,
                            columnNumber: 25
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/app/project/[id]/page.js",
                        lineNumber: 116,
                        columnNumber: 21
                    }, this),
                    gallery.length > 1 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].galleryControls,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: prevImage,
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].galleryBtn,
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$left$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronLeft$3e$__["ChevronLeft"], {
                                    size: 20
                                }, void 0, false, {
                                    fileName: "[project]/src/app/project/[id]/page.js",
                                    lineNumber: 139,
                                    columnNumber: 33
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/app/project/[id]/page.js",
                                lineNumber: 138,
                                columnNumber: 29
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: nextImage,
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].galleryBtn,
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$right$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronRight$3e$__["ChevronRight"], {
                                    size: 20
                                }, void 0, false, {
                                    fileName: "[project]/src/app/project/[id]/page.js",
                                    lineNumber: 142,
                                    columnNumber: 33
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/app/project/[id]/page.js",
                                lineNumber: 141,
                                columnNumber: 29
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/project/[id]/page.js",
                        lineNumber: 137,
                        columnNumber: 25
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/project/[id]/page.js",
                lineNumber: 115,
                columnNumber: 17
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].contentRow,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].contentCard,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].label,
                                children: "PRODUCT STORY"
                            }, void 0, false, {
                                fileName: "[project]/src/app/project/[id]/page.js",
                                lineNumber: 155,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].sectionHeading,
                                children: "Key features shipped"
                            }, void 0, false, {
                                fileName: "[project]/src/app/project/[id]/page.js",
                                lineNumber: 156,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].featureList,
                                children: caseStudy?.features?.map((feature, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].featureItem,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].featureIndex,
                                                children: String(i + 1).padStart(2, '0')
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/project/[id]/page.js",
                                                lineNumber: 161,
                                                columnNumber: 33
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].featureText,
                                                children: feature
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/project/[id]/page.js",
                                                lineNumber: 162,
                                                columnNumber: 33
                                            }, this)
                                        ]
                                    }, i, true, {
                                        fileName: "[project]/src/app/project/[id]/page.js",
                                        lineNumber: 160,
                                        columnNumber: 29
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/src/app/project/[id]/page.js",
                                lineNumber: 158,
                                columnNumber: 21
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/project/[id]/page.js",
                        lineNumber: 154,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].contentCard,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].label,
                                children: "STACK REASONING"
                            }, void 0, false, {
                                fileName: "[project]/src/app/project/[id]/page.js",
                                lineNumber: 170,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].sectionHeading,
                                children: "Why these tools"
                            }, void 0, false, {
                                fileName: "[project]/src/app/project/[id]/page.js",
                                lineNumber: 171,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                style: {
                                    color: '#737373',
                                    marginBottom: '2rem',
                                    fontSize: '0.9rem'
                                },
                                children: "Pulled straight from the engineering decisions."
                            }, void 0, false, {
                                fileName: "[project]/src/app/project/[id]/page.js",
                                lineNumber: 172,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].stackGrid,
                                children: caseStudy?.stackReasoning?.map((item, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].stackItem,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].stackHeader,
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].stackName,
                                                    children: item.tool
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/project/[id]/page.js",
                                                    lineNumber: 180,
                                                    columnNumber: 37
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/project/[id]/page.js",
                                                lineNumber: 179,
                                                columnNumber: 33
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].stackReason,
                                                children: item.reason
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/project/[id]/page.js",
                                                lineNumber: 182,
                                                columnNumber: 33
                                            }, this)
                                        ]
                                    }, i, true, {
                                        fileName: "[project]/src/app/project/[id]/page.js",
                                        lineNumber: 178,
                                        columnNumber: 29
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/src/app/project/[id]/page.js",
                                lineNumber: 176,
                                columnNumber: 21
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/project/[id]/page.js",
                        lineNumber: 169,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/project/[id]/page.js",
                lineNumber: 151,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/project/[id]/page.js",
        lineNumber: 49,
        columnNumber: 9
    }, this);
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__fbb8c1ce._.js.map