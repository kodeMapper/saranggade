module.exports = [
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[project]/src/data/resume.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "resumeData",
    ()=>resumeData
]);
const resumeData = {
    personalInfo: {
        name: "Sarang Gade",
        role: "Full-Stack Developer",
        location: "Nagpur, Maharashtra - 440013",
        email: "saranganilgade@gmail.com",
        phone: "7720059749",
        linkedin: "https://www.linkedin.com/in/sarang-gade",
        github: "https://github.com/kodeMapper",
        leetcode: "https://leetcode.com/u/Kodemapper/",
        image: "/images/profile.jpg"
    },
    education: [
        {
            institution: "Shri. Ramdeobaba College of Engineering and Management",
            degree: "Bachelor of Technology in Electronics and Computer Science",
            duration: "Aug. 2023 – Present",
            location: "Nagpur, Maharashtra",
            grade: "CGPA: 9.44/10"
        },
        {
            institution: "Shri. Ramdeobaba College of Engineering and Management",
            degree: "Minor in Information Technology",
            duration: "Aug. 2024 – Present",
            location: "Nagpur, Maharashtra",
            grade: "Grade: AA"
        }
    ],
    experience: [
        {
            title: "Full-stack Developer Intern",
            company: "AARA Green Infosolutions Pvt. Ltd.",
            duration: "April 2025 – August 2025",
            location: "Nagpur, Maharashtra",
            highlights: [
                "ReactJS Landing Page: Built a responsive multi-section site showcasing services and enabling worker self-registration.",
                "Admin Panel (React, Supabase, Express): Developed a role-based dashboard for bookings, workers, and services with REST APIs and PostgreSQL integration.",
                "Backend Services: Implemented secure ExpressJS endpoints, authentication middleware, and optimized data flows (sub-200 ms response).",
                "Team Collaboration: Worked in an agile startup environment, managing sprints, code reviews, and CI/CD via GitHub."
            ]
        },
        {
            title: "Software Lead",
            company: "Embedded Club, RCOEM",
            duration: "Sep 2025 – Present",
            location: "Nagpur, Maharashtra",
            highlights: []
        },
        {
            title: "Development Hackathons",
            company: "Frontend/Backend Developer",
            duration: "Sep 2024 – Present",
            location: "Maharashtra",
            highlights: []
        }
    ],
    projects: [
        {
            name: "PulseAI – Health Risk Prediction",
            tech: "Python, Flask, React, MongoDB",
            date: "Nov 2025",
            github: "https://github.com/kodeMapper/PulseAI",
            demo: "#",
            image: "linear-gradient(to right, #4facfe 0%, #00f2fe 100%)",
            points: [
                "ML system for maternal health risk prediction (86.7% accuracy).",
                "End-to-end pipeline: model training, Flask API, React dashboard.",
                "Deployed on Vercel and Render."
            ]
        },
        {
            name: "Stampede Management",
            tech: "YOLOv8, OpenCV, Flask",
            date: "Oct 2025",
            github: "https://github.com/kodeMapper/Stampede-Management",
            demo: "#",
            image: "linear-gradient(120deg, #f6d365 0%, #fda085 100%)",
            points: [
                "Real-time crowd and weapon detection using YOLOv8.",
                "90% accuracy with sub-100ms latency.",
                "Flask backend with live dashboard."
            ]
        },
        {
            name: "GPS & Health Monitor",
            tech: "Node.js, IoT, ESP32",
            date: "April 2025",
            github: "https://github.com/kodeMapper/GPS-Health-Monitor",
            demo: "#",
            image: "linear-gradient(to top, #c471f5 0%, #fa71cd 100%)",
            points: [
                "ESP32 system for real-time GPS and health tracking.",
                "Responsive web dashboard and mobile app."
            ]
        },
        {
            name: "RakshaSetu Safety App",
            tech: "JavaScript, HTML, CSS",
            date: "Nov 2024",
            github: "https://github.com/kodeMapper/RakshaSetu",
            demo: "#",
            image: "linear-gradient(to top, #ebc0fd 0%, #d9ded8 100%)",
            points: [
                "Safety app for women/children with route monitoring.",
                "Real-time tracking and alert mechanisms."
            ]
        },
        {
            name: "Ben 10 Universe",
            tech: "Frontend, Animation",
            date: "July 2024",
            github: "https://github.com/kodeMapper/Ben10-Universe",
            demo: "#",
            image: "linear-gradient(180deg, #2af598 0%, #009efd 100%)",
            points: [
                "Interactive fan site with themed visuals.",
                "Animation effects reflecting cartoon aesthetic."
            ]
        }
    ],
    skills: {
        languages: [
            "JavaScript",
            "Node",
            "Express",
            "HTML",
            "CSS",
            "Bootstrap",
            "Python",
            "Java",
            "C",
            "PHP",
            "MySQL"
        ],
        tools: [
            "VS Code",
            "Eclipse",
            "Intellij",
            "MIT App Inventor",
            "Postman",
            "MongoDB"
        ],
        frameworks: [
            "Vercel",
            "Git",
            "GitHub",
            "MS Power BI",
            "Tableau",
            "Star UML",
            "Render"
        ]
    }
};
}),
"[project]/src/app/project/project.module.css [app-ssr] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "coverImage": "project-module__8jn9OG__coverImage",
  "description": "project-module__8jn9OG__description",
  "hero": "project-module__8jn9OG__hero",
  "linkBtn": "project-module__8jn9OG__linkBtn",
  "links": "project-module__8jn9OG__links",
  "meta": "project-module__8jn9OG__meta",
  "overlay": "project-module__8jn9OG__overlay",
  "page": "project-module__8jn9OG__page",
  "primaryBtn": "project-module__8jn9OG__primaryBtn",
  "sidebar": "project-module__8jn9OG__sidebar",
  "subtitle": "project-module__8jn9OG__subtitle",
  "tag": "project-module__8jn9OG__tag",
  "techStack": "project-module__8jn9OG__techStack",
  "title": "project-module__8jn9OG__title",
});
}),
"[project]/src/app/project/[id]/page.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ProjectDetail
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$resume$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/data/resume.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f$project$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/src/app/project/project.module.css [app-ssr] (css module)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
// Helper to get project data by ID/Slug (using index for simplicity or adding slug to data)
const getProject = (id)=>{
    // In a real app, you'd find by slug. Here we use array index for demo.
    return __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$resume$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["resumeData"].projects[id];
};
function ProjectDetail({ params }) {
    const project = getProject(params.id);
    if (!project) return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f$project$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].page,
        children: "Project not found"
    }, void 0, false, {
        fileName: "[project]/src/app/project/[id]/page.js",
        lineNumber: 16,
        columnNumber: 26
    }, this);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f$project$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].page,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f$project$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].hero,
                children: [
                    project.image && !project.image.startsWith('linear') ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                        src: project.image,
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f$project$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].coverImage,
                        alt: project.name
                    }, void 0, false, {
                        fileName: "[project]/src/app/project/[id]/page.js",
                        lineNumber: 22,
                        columnNumber: 21
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f$project$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].coverImage,
                        style: {
                            background: project.image || '#1e293b'
                        }
                    }, void 0, false, {
                        fileName: "[project]/src/app/project/[id]/page.js",
                        lineNumber: 24,
                        columnNumber: 21
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f$project$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].overlay,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f$project$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].title,
                            children: project.name
                        }, void 0, false, {
                            fileName: "[project]/src/app/project/[id]/page.js",
                            lineNumber: 27,
                            columnNumber: 21
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/app/project/[id]/page.js",
                        lineNumber: 26,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/project/[id]/page.js",
                lineNumber: 20,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f$project$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].meta,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f$project$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].mainContent,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f$project$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].subtitle,
                                children: "About Project"
                            }, void 0, false, {
                                fileName: "[project]/src/app/project/[id]/page.js",
                                lineNumber: 33,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f$project$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].description,
                                children: project.points ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                    style: {
                                        listStyle: 'disc',
                                        paddingLeft: '20px'
                                    },
                                    children: project.points.map((p, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                            style: {
                                                marginBottom: '1rem'
                                            },
                                            children: p
                                        }, i, false, {
                                            fileName: "[project]/src/app/project/[id]/page.js",
                                            lineNumber: 37,
                                            columnNumber: 63
                                        }, this))
                                }, void 0, false, {
                                    fileName: "[project]/src/app/project/[id]/page.js",
                                    lineNumber: 36,
                                    columnNumber: 29
                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    children: project.description
                                }, void 0, false, {
                                    fileName: "[project]/src/app/project/[id]/page.js",
                                    lineNumber: 40,
                                    columnNumber: 29
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/app/project/[id]/page.js",
                                lineNumber: 34,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                style: {
                                    marginTop: '3rem'
                                },
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                    href: "/",
                                    style: {
                                        textDecoration: 'underline'
                                    },
                                    children: "← Back to Home"
                                }, void 0, false, {
                                    fileName: "[project]/src/app/project/[id]/page.js",
                                    lineNumber: 45,
                                    columnNumber: 25
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/app/project/[id]/page.js",
                                lineNumber: 44,
                                columnNumber: 21
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/project/[id]/page.js",
                        lineNumber: 32,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("aside", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f$project$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].sidebar,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f$project$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].subtitle,
                                children: "Tech Stack"
                            }, void 0, false, {
                                fileName: "[project]/src/app/project/[id]/page.js",
                                lineNumber: 50,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f$project$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].techStack,
                                children: project.techStack?.map((t)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f$project$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].tag,
                                        children: t
                                    }, t, false, {
                                        fileName: "[project]/src/app/project/[id]/page.js",
                                        lineNumber: 52,
                                        columnNumber: 54
                                    }, this)) || project.tech.split(', ').map((t)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f$project$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].tag,
                                        children: t
                                    }, t, false, {
                                        fileName: "[project]/src/app/project/[id]/page.js",
                                        lineNumber: 53,
                                        columnNumber: 63
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/src/app/project/[id]/page.js",
                                lineNumber: 51,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f$project$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].subtitle,
                                children: "Links"
                            }, void 0, false, {
                                fileName: "[project]/src/app/project/[id]/page.js",
                                lineNumber: 56,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f$project$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].links,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                        href: project.demo,
                                        target: "_blank",
                                        rel: "noopener noreferrer",
                                        className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f$project$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].linkBtn} ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f$project$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].primaryBtn}`,
                                        children: "View Live"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/project/[id]/page.js",
                                        lineNumber: 58,
                                        columnNumber: 25
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                        href: project.github,
                                        target: "_blank",
                                        rel: "noopener noreferrer",
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f$project$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].linkBtn,
                                        children: "GitHub"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/project/[id]/page.js",
                                        lineNumber: 61,
                                        columnNumber: 25
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/project/[id]/page.js",
                                lineNumber: 57,
                                columnNumber: 21
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/project/[id]/page.js",
                        lineNumber: 49,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/project/[id]/page.js",
                lineNumber: 31,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/project/[id]/page.js",
        lineNumber: 19,
        columnNumber: 9
    }, this);
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__aa3dc170._.js.map