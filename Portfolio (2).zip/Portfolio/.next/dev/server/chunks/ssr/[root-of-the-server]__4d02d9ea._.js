module.exports = [
"[project]/src/app/favicon.ico.mjs { IMAGE => \"[project]/src/app/favicon.ico (static in ecmascript, tag client)\" } [app-rsc] (structured image object, ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/src/app/favicon.ico.mjs { IMAGE => \"[project]/src/app/favicon.ico (static in ecmascript, tag client)\" } [app-rsc] (structured image object, ecmascript)"));
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[project]/src/app/layout.js [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/src/app/layout.js [app-rsc] (ecmascript)"));
}),
"[project]/src/data/resume.js [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "resumeData",
    ()=>resumeData
]);
const resumeData = {
    personalInfo: {
        name: "Sarang Gade",
        role: "Full-Stack Developer",
        location: "Nagpur, Maharashtra - 440013",
        email: "saranganilgade@gmail.com",
        phone: "7720059749",
        linkedin: "https://www.linkedin.com/in/sarang-gade",
        github: "https://github.com/kodeMapper",
        leetcode: "https://leetcode.com/u/Kodemapper/",
        image: "/images/profile.jpg"
    },
    education: [
        {
            institution: "Shri. Ramdeobaba College of Engineering and Management",
            degree: "Bachelor of Technology in Electronics and Computer Science",
            duration: "Aug. 2023 – Present",
            location: "Nagpur, Maharashtra",
            grade: "CGPA: 9.44/10"
        },
        {
            institution: "Shri. Ramdeobaba College of Engineering and Management",
            degree: "Minor in Information Technology",
            duration: "Aug. 2024 – Present",
            location: "Nagpur, Maharashtra",
            grade: "Grade: AA"
        }
    ],
    experience: [
        {
            title: "Full-stack Developer Intern",
            company: "AARA Green Infosolutions Pvt. Ltd.",
            duration: "April 2025 – August 2025",
            location: "Nagpur, Maharashtra",
            highlights: [
                "ReactJS Landing Page: Built a responsive multi-section site showcasing services and enabling worker self-registration.",
                "Admin Panel (React, Supabase, Express): Developed a role-based dashboard for bookings, workers, and services with REST APIs and PostgreSQL integration.",
                "Backend Services: Implemented secure ExpressJS endpoints, authentication middleware, and optimized data flows (sub-200 ms response).",
                "Team Collaboration: Worked in an agile startup environment, managing sprints, code reviews, and CI/CD via GitHub."
            ]
        },
        {
            title: "Software Lead",
            company: "Embedded Club, RCOEM",
            duration: "Sep 2025 – Present",
            location: "Nagpur, Maharashtra",
            highlights: []
        },
        {
            title: "Development Hackathons",
            company: "Frontend/Backend Developer",
            duration: "Sep 2024 – Present",
            location: "Maharashtra",
            highlights: []
        }
    ],
    projects: [
        {
            name: "PulseAI – Health Risk Prediction",
            tech: "Python, Flask, React, MongoDB",
            date: "Nov 2025",
            github: "https://github.com/kodeMapper/PulseAI",
            demo: "#",
            image: "linear-gradient(to right, #4facfe 0%, #00f2fe 100%)",
            points: [
                "ML system for maternal health risk prediction (86.7% accuracy).",
                "End-to-end pipeline: model training, Flask API, React dashboard.",
                "Deployed on Vercel and Render."
            ],
            caseStudy: {
                summary: "PulseAI bridges the gap in early maternal health diagnosis using machine learning. It provides actionable insights for healthcare providers by predicting potential risks based on patient vitals.",
                features: [
                    "Real-time Risk Analysis with 86.7% accuracy",
                    "Interactive Dashboard for Doctors",
                    "Secure Patient Data Storage",
                    "Exportable Medical Reports"
                ],
                stackReasoning: [
                    {
                        tool: "Python/Scikit-Learn",
                        reason: "Standard for ML model training and evaluation."
                    },
                    {
                        tool: "Flask",
                        reason: "Lightweight backend to serve ML predictions via API."
                    },
                    {
                        tool: "React",
                        reason: "Dynamic UI for real-time data visualization."
                    },
                    {
                        tool: "MongoDB",
                        reason: "Flexible schema for key-value patient data."
                    }
                ],
                challenges: [
                    "Handling imbalanced datasets for rare high-risk cases.",
                    "Optimizing inference time for real-time feedback."
                ],
                gallery: [
                    "linear-gradient(to right, #4facfe 0%, #00f2fe 100%)",
                    "linear-gradient(to right, #43e97b 0%, #38f9d7 100%)",
                    "linear-gradient(to right, #fa709a 0%, #fee140 100%)"
                ]
            }
        },
        {
            name: "Stampede Management",
            tech: "YOLOv8, OpenCV, Flask",
            date: "Oct 2025",
            github: "https://github.com/kodeMapper/Stampede-Management",
            demo: "#",
            image: "linear-gradient(120deg, #f6d365 0%, #fda085 100%)",
            points: [
                "Real-time crowd and weapon detection using YOLOv8.",
                "90% accuracy with sub-100ms latency.",
                "Flask backend with live dashboard."
            ],
            caseStudy: {
                summary: "An advanced computer vision system designed to prevent stampedes in high-density areas. It autonomously monitors crowd density and detects potential threats like weapons in real-time.",
                features: [
                    "Crowd Density Estimation",
                    "Weapon/Threat Detection",
                    "Auto-alert System for Authorities",
                    "Heatmap Visualization"
                ],
                stackReasoning: [
                    {
                        tool: "YOLOv8",
                        reason: "State-of-the-art object detection speed and accuracy."
                    },
                    {
                        tool: "OpenCV",
                        reason: "Efficient video stream processing."
                    },
                    {
                        tool: "WebSockets",
                        reason: "Low-latency alert delivery to the dashboard."
                    }
                ],
                challenges: [
                    "Detecting small objects in crowded, low-light scenes.",
                    "Processing multiple video streams concurrently without lag."
                ],
                gallery: [
                    "linear-gradient(120deg, #f6d365 0%, #fda085 100%)",
                    "linear-gradient(120deg, #84fab0 0%, #8fd3f4 100%)",
                    "linear-gradient(120deg, #a1c4fd 0%, #c2e9fb 100%)"
                ]
            }
        },
        {
            name: "GPS & Health Monitor",
            tech: "Node.js, IoT, ESP32",
            date: "April 2025",
            github: "https://github.com/kodeMapper/GPS-Health-Monitor",
            demo: "#",
            image: "linear-gradient(to top, #c471f5 0%, #fa71cd 100%)",
            points: [
                "ESP32 system for real-time GPS and health tracking.",
                "Responsive web dashboard and mobile app."
            ],
            caseStudy: {
                summary: "A unified IoT solution for tracking location and vital signs. Essential for elderly care and remote patient monitoring, ensuring peace of mind for caregivers.",
                features: [
                    "Live GPS Tracking via Google Maps API",
                    "Heart Rate & SpO2 Monitoring",
                    "Emergency SOS Button",
                    "Mobile-First Responsive Dashboard"
                ],
                stackReasoning: [
                    {
                        tool: "ESP32",
                        reason: "Low-power microcontroller with built-in WiFi/Bluetooth."
                    },
                    {
                        tool: "Node.js",
                        reason: "Non-blocking I/O for handling multiple sensor streams."
                    },
                    {
                        tool: "Socket.io",
                        reason: "Instant data updates on the client side."
                    }
                ],
                challenges: [
                    "Minimizing battery consumption on the hardware.",
                    "Ensuring connection stability in poor network areas."
                ],
                gallery: [
                    "linear-gradient(to top, #c471f5 0%, #fa71cd 100%)",
                    "linear-gradient(to top, #30cfd0 0%, #330867 100%)",
                    "linear-gradient(to top, #5f72bd 0%, #9b23ea 100%)"
                ]
            }
        },
        {
            name: "RakshaSetu Safety App",
            tech: "JavaScript, HTML, CSS",
            date: "Nov 2024",
            github: "https://github.com/kodeMapper/RakshaSetu",
            demo: "#",
            image: "linear-gradient(to top, #ebc0fd 0%, #d9ded8 100%)",
            points: [
                "Safety app for women/children with route monitoring.",
                "Real-time tracking and alert mechanisms."
            ],
            caseStudy: {
                summary: "RakshaSetu empowers user safety through community tracking and rapid emergency response. It calculates safe routes and keeps trusted contacts informed.",
                features: [
                    "Safe Route Navigation",
                    "One-Tap Panic Button",
                    "Community Safety Score Maps",
                    "Offline SMS Alerts"
                ],
                stackReasoning: [
                    {
                        tool: "Leaflet.js",
                        reason: "Lightweight mapping library for route rendering."
                    },
                    {
                        tool: "Firebase",
                        reason: "Real-time database for user locations and alerts."
                    },
                    {
                        tool: "PWA",
                        reason: "Installable app experience without app store friction."
                    }
                ],
                challenges: [
                    "Accurate geolocation tracking in urban canyons.",
                    "Balancing privacy with safety requirements."
                ],
                gallery: [
                    "linear-gradient(to top, #ebc0fd 0%, #d9ded8 100%)",
                    "linear-gradient(to top, #a8edea 0%, #fed6e3 100%)",
                    "linear-gradient(to top, #e6e9f0 0%, #eef1f5 100%)"
                ]
            }
        },
        {
            name: "Ben 10 Universe",
            tech: "Frontend, Animation",
            date: "July 2024",
            github: "https://github.com/kodeMapper/Ben10-Universe",
            demo: "#",
            image: "linear-gradient(180deg, #2af598 0%, #009efd 100%)",
            points: [
                "Interactive fan site with themed visuals.",
                "Animation effects reflecting cartoon aesthetic."
            ],
            caseStudy: {
                summary: "A nostalgic, immersive web experience celebrating the Ben 10 universe. It heavily leverages CSS animations and sound design to recreate the feel of the show's interface (Omnitrix).",
                features: [
                    "Omnitrix Transformation Animations",
                    "Character Database with Stats",
                    "Themed Sound Effects",
                    "Responsive Cartoon Layout"
                ],
                stackReasoning: [
                    {
                        tool: "Vanilla CSS",
                        reason: "Maximum control over complex keyframe animations."
                    },
                    {
                        tool: "JavaScript",
                        reason: "Managing state for interactive alien switching."
                    },
                    {
                        tool: "HTML5 Audio",
                        reason: "Triggering SFX for immersive feedback."
                    }
                ],
                challenges: [
                    "Synchronizing multiple animations for a cohesive 'transformation' effect.",
                    "Optimizing assets (images/audio) for fast load times."
                ],
                gallery: [
                    "linear-gradient(180deg, #2af598 0%, #009efd 100%)",
                    "linear-gradient(180deg, #2af598 0%, #009efd 100%)",
                    "linear-gradient(180deg, #2af598 0%, #009efd 100%)"
                ]
            }
        }
    ],
    skills: {
        languages: [
            "JavaScript",
            "Node",
            "Express",
            "HTML",
            "CSS",
            "Bootstrap",
            "Python",
            "Java",
            "C",
            "PHP",
            "MySQL"
        ],
        tools: [
            "VS Code",
            "Eclipse",
            "Intellij",
            "MIT App Inventor",
            "Postman",
            "MongoDB"
        ],
        frameworks: [
            "Vercel",
            "Git",
            "GitHub",
            "MS Power BI",
            "Tableau",
            "Star UML",
            "Render"
        ]
    }
};
}),
"[project]/src/app/project/[id]/project.module.css [app-rsc] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "actionTitle": "project-module__KCYNdq__actionTitle",
  "actionsCard": "project-module__KCYNdq__actionsCard",
  "backLink": "project-module__KCYNdq__backLink",
  "card": "project-module__KCYNdq__card",
  "container": "project-module__KCYNdq__container",
  "contentCard": "project-module__KCYNdq__contentCard",
  "contentRow": "project-module__KCYNdq__contentRow",
  "featureIndex": "project-module__KCYNdq__featureIndex",
  "featureItem": "project-module__KCYNdq__featureItem",
  "featureList": "project-module__KCYNdq__featureList",
  "featureText": "project-module__KCYNdq__featureText",
  "galleryBtn": "project-module__KCYNdq__galleryBtn",
  "galleryControls": "project-module__KCYNdq__galleryControls",
  "galleryImage": "project-module__KCYNdq__galleryImage",
  "galleryImageContainer": "project-module__KCYNdq__galleryImageContainer",
  "gallerySection": "project-module__KCYNdq__gallerySection",
  "galleryTrack": "project-module__KCYNdq__galleryTrack",
  "gridContainer": "project-module__KCYNdq__gridContainer",
  "heroCard": "project-module__KCYNdq__heroCard",
  "highlightItem": "project-module__KCYNdq__highlightItem",
  "highlightNumber": "project-module__KCYNdq__highlightNumber",
  "highlightText": "project-module__KCYNdq__highlightText",
  "highlightsGrid": "project-module__KCYNdq__highlightsGrid",
  "label": "project-module__KCYNdq__label",
  "navBar": "project-module__KCYNdq__navBar",
  "navItem": "project-module__KCYNdq__navItem",
  "navLinks": "project-module__KCYNdq__navLinks",
  "sectionHeading": "project-module__KCYNdq__sectionHeading",
  "sidebar": "project-module__KCYNdq__sidebar",
  "stackGrid": "project-module__KCYNdq__stackGrid",
  "stackHeader": "project-module__KCYNdq__stackHeader",
  "stackItem": "project-module__KCYNdq__stackItem",
  "stackName": "project-module__KCYNdq__stackName",
  "stackReason": "project-module__KCYNdq__stackReason",
  "statBox": "project-module__KCYNdq__statBox",
  "statLabel": "project-module__KCYNdq__statLabel",
  "statValue": "project-module__KCYNdq__statValue",
  "statsGrid": "project-module__KCYNdq__statsGrid",
  "summary": "project-module__KCYNdq__summary",
  "techIcon": "project-module__KCYNdq__techIcon",
  "techList": "project-module__KCYNdq__techList",
  "title": "project-module__KCYNdq__title",
});
}),
"[project]/src/app/project/[id]/page.js [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ProjectDetail
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$resume$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/data/resume.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$api$2f$navigation$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/next/dist/api/navigation.react-server.js [app-rsc] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$navigation$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/components/navigation.react-server.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/src/app/project/[id]/project.module.css [app-rsc] (css module)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.react-server.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$left$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronLeft$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/chevron-left.js [app-rsc] (ecmascript) <export default as ChevronLeft>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$right$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronRight$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/chevron-right.js [app-rsc] (ecmascript) <export default as ChevronRight>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/components/AnimatePresence/index.mjs [app-rsc] (ecmascript)");
;
;
;
;
;
;
;
;
function ProjectDetail({ params }) {
    // Unwrap params using React.use() for Next.js 15+ support
    const unwrappedParams = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"].use(params);
    const id = parseInt(unwrappedParams.id);
    if (isNaN(id) || id < 0 || id >= __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$resume$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["resumeData"].projects.length) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$navigation$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["notFound"])();
    }
    const project = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$resume$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["resumeData"].projects[id];
    const { caseStudy } = project;
    // If no case study data, fallback or show basics? 
    // We added mock data for all, so it should be fine.
    // Gallery State
    const [currentImageIndex, setCurrentImageIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useState"])(0);
    const gallery = caseStudy?.gallery || [
        project.image
    ]; // Fallback to main image
    const nextImage = ()=>{
        setCurrentImageIndex((prev)=>(prev + 1) % gallery.length);
    };
    const prevImage = ()=>{
        setCurrentImageIndex((prev)=>(prev - 1 + gallery.length) % gallery.length);
    };
    // Auto-slide
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const timer = setInterval(nextImage, 4000); // 4 seconds
        return ()=>clearInterval(timer);
    }, [
        gallery.length
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].container,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].navBar,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        href: "/",
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].backLink,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$left$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronLeft$3e$__["ChevronLeft"], {
                                size: 16
                            }, void 0, false, {
                                fileName: "[project]/src/app/project/[id]/page.js",
                                lineNumber: 49,
                                columnNumber: 21
                            }, this),
                            " Back to home"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/project/[id]/page.js",
                        lineNumber: 48,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].navLinks,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                href: project.github,
                                target: "_blank",
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].navItem,
                                children: "Github"
                            }, void 0, false, {
                                fileName: "[project]/src/app/project/[id]/page.js",
                                lineNumber: 52,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                href: project.demo,
                                target: "_blank",
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].navItem,
                                children: "Live"
                            }, void 0, false, {
                                fileName: "[project]/src/app/project/[id]/page.js",
                                lineNumber: 53,
                                columnNumber: 21
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/project/[id]/page.js",
                        lineNumber: 51,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/project/[id]/page.js",
                lineNumber: 47,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].gridContainer,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].card} ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].heroCard}`,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].label,
                                children: "CASE STUDY"
                            }, void 0, false, {
                                fileName: "[project]/src/app/project/[id]/page.js",
                                lineNumber: 61,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].title,
                                children: project.name
                            }, void 0, false, {
                                fileName: "[project]/src/app/project/[id]/page.js",
                                lineNumber: 62,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].summary,
                                children: caseStudy?.summary || project.points.join(' ')
                            }, void 0, false, {
                                fileName: "[project]/src/app/project/[id]/page.js",
                                lineNumber: 63,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].highlightsGrid,
                                children: caseStudy?.features?.slice(0, 3).map((feature, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].highlightItem,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].highlightNumber,
                                                children: [
                                                    "Feature ",
                                                    i + 1
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/project/[id]/page.js",
                                                lineNumber: 70,
                                                columnNumber: 33
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].highlightText,
                                                children: feature
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/project/[id]/page.js",
                                                lineNumber: 71,
                                                columnNumber: 33
                                            }, this)
                                        ]
                                    }, i, true, {
                                        fileName: "[project]/src/app/project/[id]/page.js",
                                        lineNumber: 69,
                                        columnNumber: 29
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/src/app/project/[id]/page.js",
                                lineNumber: 67,
                                columnNumber: 21
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/project/[id]/page.js",
                        lineNumber: 60,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].sidebar,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].actionsCard,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].actionTitle,
                                    children: "PROJECT LINKS"
                                }, void 0, false, {
                                    fileName: "[project]/src/app/project/[id]/page.js",
                                    lineNumber: 80,
                                    columnNumber: 25
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statsGrid,
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statBox,
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statLabel,
                                                    children: "KEY FEATURES"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/project/[id]/page.js",
                                                    lineNumber: 84,
                                                    columnNumber: 33
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statValue,
                                                    children: caseStudy?.features?.length || 0
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/project/[id]/page.js",
                                                    lineNumber: 85,
                                                    columnNumber: 33
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/project/[id]/page.js",
                                            lineNumber: 83,
                                            columnNumber: 29
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statBox,
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statLabel,
                                                    children: "TECH USED"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/project/[id]/page.js",
                                                    lineNumber: 88,
                                                    columnNumber: 33
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statValue,
                                                    children: project.tech.split(',').length
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/project/[id]/page.js",
                                                    lineNumber: 89,
                                                    columnNumber: 33
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/project/[id]/page.js",
                                            lineNumber: 87,
                                            columnNumber: 29
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/project/[id]/page.js",
                                    lineNumber: 82,
                                    columnNumber: 25
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].techList,
                                    children: project.tech.split(',').slice(0, 5).map((t, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].techIcon,
                                            title: t.trim(),
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                                src: `https://cdn.simpleicons.org/${t.trim().toLowerCase().replace(/[\s\.]/g, '')}`,
                                                onError: (e)=>{
                                                    e.target.style.display = 'none';
                                                },
                                                alt: ""
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/project/[id]/page.js",
                                                lineNumber: 96,
                                                columnNumber: 37
                                            }, this)
                                        }, i, false, {
                                            fileName: "[project]/src/app/project/[id]/page.js",
                                            lineNumber: 95,
                                            columnNumber: 33
                                        }, this))
                                }, void 0, false, {
                                    fileName: "[project]/src/app/project/[id]/page.js",
                                    lineNumber: 93,
                                    columnNumber: 25
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/project/[id]/page.js",
                            lineNumber: 79,
                            columnNumber: 21
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/app/project/[id]/page.js",
                        lineNumber: 78,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/project/[id]/page.js",
                lineNumber: 58,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].gallerySection,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].galleryTrack,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["AnimatePresence"], {
                            mode: "wait",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["motion"].div, {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].galleryImageContainer,
                                initial: {
                                    opacity: 0,
                                    x: 100
                                },
                                animate: {
                                    opacity: 1,
                                    x: 0
                                },
                                exit: {
                                    opacity: 0,
                                    x: -100
                                },
                                transition: {
                                    duration: 0.5
                                },
                                children: gallery[currentImageIndex].startsWith('linear') ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    style: {
                                        width: '100%',
                                        height: '100%',
                                        background: gallery[currentImageIndex]
                                    }
                                }, void 0, false, {
                                    fileName: "[project]/src/app/project/[id]/page.js",
                                    lineNumber: 122,
                                    columnNumber: 33
                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                    src: gallery[currentImageIndex],
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].galleryImage,
                                    alt: "UI Screenshot"
                                }, void 0, false, {
                                    fileName: "[project]/src/app/project/[id]/page.js",
                                    lineNumber: 124,
                                    columnNumber: 33
                                }, this)
                            }, currentImageIndex, false, {
                                fileName: "[project]/src/app/project/[id]/page.js",
                                lineNumber: 112,
                                columnNumber: 25
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/app/project/[id]/page.js",
                            lineNumber: 111,
                            columnNumber: 21
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/app/project/[id]/page.js",
                        lineNumber: 110,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].galleryControls,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: prevImage,
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].galleryBtn,
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$left$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronLeft$3e$__["ChevronLeft"], {
                                    size: 20
                                }, void 0, false, {
                                    fileName: "[project]/src/app/project/[id]/page.js",
                                    lineNumber: 132,
                                    columnNumber: 25
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/app/project/[id]/page.js",
                                lineNumber: 131,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: nextImage,
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].galleryBtn,
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$right$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronRight$3e$__["ChevronRight"], {
                                    size: 20
                                }, void 0, false, {
                                    fileName: "[project]/src/app/project/[id]/page.js",
                                    lineNumber: 135,
                                    columnNumber: 25
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/app/project/[id]/page.js",
                                lineNumber: 134,
                                columnNumber: 21
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/project/[id]/page.js",
                        lineNumber: 130,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/project/[id]/page.js",
                lineNumber: 109,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].contentRow,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].contentCard,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].label,
                                children: "PRODUCT STORY"
                            }, void 0, false, {
                                fileName: "[project]/src/app/project/[id]/page.js",
                                lineNumber: 146,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].sectionHeading,
                                children: "Key features shipped"
                            }, void 0, false, {
                                fileName: "[project]/src/app/project/[id]/page.js",
                                lineNumber: 147,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].featureList,
                                children: caseStudy?.features?.map((feature, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].featureItem,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].featureIndex,
                                                children: String(i + 1).padStart(2, '0')
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/project/[id]/page.js",
                                                lineNumber: 152,
                                                columnNumber: 33
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].featureText,
                                                children: feature
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/project/[id]/page.js",
                                                lineNumber: 153,
                                                columnNumber: 33
                                            }, this)
                                        ]
                                    }, i, true, {
                                        fileName: "[project]/src/app/project/[id]/page.js",
                                        lineNumber: 151,
                                        columnNumber: 29
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/src/app/project/[id]/page.js",
                                lineNumber: 149,
                                columnNumber: 21
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/project/[id]/page.js",
                        lineNumber: 145,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].contentCard,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].label,
                                children: "STACK REASONING"
                            }, void 0, false, {
                                fileName: "[project]/src/app/project/[id]/page.js",
                                lineNumber: 161,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].sectionHeading,
                                children: "Why these tools"
                            }, void 0, false, {
                                fileName: "[project]/src/app/project/[id]/page.js",
                                lineNumber: 162,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                style: {
                                    color: '#737373',
                                    marginBottom: '2rem',
                                    fontSize: '0.9rem'
                                },
                                children: "Pulled straight from the engineering decisions."
                            }, void 0, false, {
                                fileName: "[project]/src/app/project/[id]/page.js",
                                lineNumber: 163,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].stackGrid,
                                children: caseStudy?.stackReasoning?.map((item, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].stackItem,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].stackHeader,
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].stackName,
                                                    children: item.tool
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/project/[id]/page.js",
                                                    lineNumber: 171,
                                                    columnNumber: 37
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/project/[id]/page.js",
                                                lineNumber: 170,
                                                columnNumber: 33
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$project$2f5b$id$5d2f$project$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].stackReason,
                                                children: item.reason
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/project/[id]/page.js",
                                                lineNumber: 173,
                                                columnNumber: 33
                                            }, this)
                                        ]
                                    }, i, true, {
                                        fileName: "[project]/src/app/project/[id]/page.js",
                                        lineNumber: 169,
                                        columnNumber: 29
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/src/app/project/[id]/page.js",
                                lineNumber: 167,
                                columnNumber: 21
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/project/[id]/page.js",
                        lineNumber: 160,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/project/[id]/page.js",
                lineNumber: 142,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/project/[id]/page.js",
        lineNumber: 45,
        columnNumber: 9
    }, this);
}
}),
"[project]/src/app/project/[id]/page.js [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/src/app/project/[id]/page.js [app-rsc] (ecmascript)"));
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__4d02d9ea._.js.map