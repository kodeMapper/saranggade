(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_cc959e57._.js",
  "static/chunks/node_modules_168cc547._.js",
  "static/chunks/src_components_37475128._.css"
],
    source: "dynamic"
});
