(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_7fc784ed._.js",
  "static/chunks/src_27eb1676._.js",
  "static/chunks/src_47eaff45._.css"
],
    source: "dynamic"
});
