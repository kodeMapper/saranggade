(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_components_d6d0031b._.js",
  "static/chunks/node_modules_85e5854a._.js",
  "static/chunks/src_components_57823a17._.css"
],
    source: "dynamic"
});
