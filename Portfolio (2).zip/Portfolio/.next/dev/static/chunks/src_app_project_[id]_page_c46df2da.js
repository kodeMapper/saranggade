(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_motion-dom_dist_es_da948acf._.js",
  "static/chunks/node_modules_framer-motion_dist_es_247c3ff9._.js",
  "static/chunks/node_modules_micromark-core-commonmark_dev_lib_fc41dd51._.js",
  "static/chunks/node_modules_7686899c._.js",
  "static/chunks/src_ed6f1146._.js",
  "static/chunks/src_1cebc868._.css"
],
    source: "dynamic"
});
